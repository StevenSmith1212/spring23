import java.net.InetAddress;

public enum MySocket {
    ;

    public static void sendMessage(InetAddress address, int port, String initialMessage) {
    }

}
